package com.example.apptest;

public class PostItem {
    private String _title;
    private String _text;

    public String getText() { return _text; }
    public String getTitle() { return _title; }

    public void setTitle(String title) { _title = title; }
    public void setText(String text) { _text = text; }


}
